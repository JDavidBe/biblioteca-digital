package com.biblioteca.usuarios;

import com.biblioteca.usuarios.application.dto.UsuarioRequestDTO;
import com.biblioteca.usuarios.domain.model.Usuario;
import com.biblioteca.usuarios.domain.usecase.UsuarioUseCase;
import com.biblioteca.usuarios.infraestructure.entry_points.GlobalExceptionHandler;
import com.biblioteca.usuarios.infraestructure.entry_points.UsuarioController;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.context.annotation.Import;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;

import java.time.LocalDateTime;
import java.util.List;

import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@WebMvcTest(controllers = UsuarioController.class)
@Import({GlobalExceptionHandler.class, TestSecurityConfig.class})
@DisplayName("UsuarioController - Pruebas de integración web")
class UsuarioControllerTest {

    @Autowired MockMvc mockMvc;
    @Autowired ObjectMapper objectMapper;
    @MockBean UsuarioUseCase usuarioUseCase;

    private Usuario usuarioSample() {
        return new Usuario(1L, "Ana García", "ana@test.com", "IED Central", "10", "ESTUDIANTE", true, LocalDateTime.now());
    }

    @Test
    @DisplayName("POST /api/usuarios - crea usuario y retorna 201")
    void crear_datosValidos_retorna201() throws Exception {
        when(usuarioUseCase.crearUsuario(any())).thenReturn(usuarioSample());

        UsuarioRequestDTO req = new UsuarioRequestDTO();
        req.setNombre("Ana García");
        req.setCorreo("ana@test.com");

        mockMvc.perform(post("/api/usuarios")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(req)))
                .andExpect(status().isCreated())
                .andExpect(jsonPath("$.exito").value(true))
                .andExpect(jsonPath("$.datos.nombre").value("Ana García"));
    }

    @Test
    @DisplayName("POST /api/usuarios - retorna 400 si nombre en blanco")
    void crear_nombreBlanco_retorna400() throws Exception {
        UsuarioRequestDTO req = new UsuarioRequestDTO();
        req.setNombre("");
        req.setCorreo("ana@test.com");

        mockMvc.perform(post("/api/usuarios")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(req)))
                .andExpect(status().isBadRequest());
    }

    @Test
    @DisplayName("GET /api/usuarios - lista todos")
    void listar_retornaLista() throws Exception {
        when(usuarioUseCase.listarTodos()).thenReturn(List.of(usuarioSample()));

        mockMvc.perform(get("/api/usuarios"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.datos.length()").value(1));
    }

    @Test
    @DisplayName("GET /api/usuarios?rol=ADMIN - filtra por rol")
    void listar_conRol_filtraPorRol() throws Exception {
        when(usuarioUseCase.listarPorRol("ADMIN")).thenReturn(List.of());

        mockMvc.perform(get("/api/usuarios").param("rol", "ADMIN"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.datos.length()").value(0));
    }

    @Test
    @DisplayName("GET /api/usuarios/{id} - retorna usuario por ID")
    void obtenerPorId_existente_retorna200() throws Exception {
        when(usuarioUseCase.obtenerPorId(1L)).thenReturn(usuarioSample());

        mockMvc.perform(get("/api/usuarios/1"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.datos.id").value(1));
    }

    @Test
    @DisplayName("GET /api/usuarios/{id} - retorna 400 si no existe")
    void obtenerPorId_noExiste_retorna400() throws Exception {
        when(usuarioUseCase.obtenerPorId(99L))
                .thenThrow(new RuntimeException("No existe usuario con id: 99"));

        mockMvc.perform(get("/api/usuarios/99"))
                .andExpect(status().isBadRequest())
                .andExpect(jsonPath("$.exito").value(false));
    }

    @Test
    @DisplayName("GET /api/usuarios/correo/{correo} - retorna usuario por correo")
    void obtenerPorCorreo_existente_retorna200() throws Exception {
        when(usuarioUseCase.obtenerPorCorreo("ana@test.com")).thenReturn(usuarioSample());

        mockMvc.perform(get("/api/usuarios/correo/ana@test.com"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.datos.correo").value("ana@test.com"));
    }

    @Test
    @DisplayName("PUT /api/usuarios/{id} - actualiza usuario")
    void actualizar_retorna200() throws Exception {
        when(usuarioUseCase.modificarUsuario(eq(1L), any())).thenReturn(usuarioSample());

        mockMvc.perform(put("/api/usuarios/1")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{\"nombre\":\"Ana Actualizada\"}"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.exito").value(true));
    }

    @Test
    @DisplayName("DELETE /api/usuarios/{id} - desactiva usuario")
    void desactivar_retorna200() throws Exception {
        doNothing().when(usuarioUseCase).desactivarUsuario(1L);

        mockMvc.perform(delete("/api/usuarios/1"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.exito").value(true));
    }

    @Test
    @DisplayName("GlobalExceptionHandler: RuntimeException retorna 400")
    void excepcionRuntime_retorna400() throws Exception {
        when(usuarioUseCase.obtenerPorId(anyLong()))
                .thenThrow(new RuntimeException("Error de negocio"));

        mockMvc.perform(get("/api/usuarios/1"))
                .andExpect(status().isBadRequest())
                .andExpect(jsonPath("$.exito").value(false))
                .andExpect(jsonPath("$.mensaje").value("Error de negocio"));
    }

    @Test
    @DisplayName("GlobalExceptionHandler: Validación retorna mensaje descriptivo")
    void excepcionValidacion_retornaMensajeDescriptivo() throws Exception {
        mockMvc.perform(post("/api/usuarios")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{\"nombre\":\"\",\"correo\":\"no-email\"}"))
                .andExpect(status().isBadRequest())
                .andExpect(jsonPath("$.mensaje").value(org.hamcrest.Matchers.containsString("Validación fallida")));
    }
}
