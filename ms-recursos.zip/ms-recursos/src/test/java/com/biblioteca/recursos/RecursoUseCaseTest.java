package com.biblioteca.recursos;

import com.biblioteca.recursos.domain.model.Recurso;
import com.biblioteca.recursos.domain.model.gateway.AlmacenamientoGateway;
import com.biblioteca.recursos.domain.model.gateway.RecursoGateway;
import com.biblioteca.recursos.domain.usecase.RecursoUseCase;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.web.multipart.MultipartFile;

import java.time.LocalDateTime;
import java.util.List;

import static org.assertj.core.api.Assertions.*;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
@DisplayName("RecursoUseCase - Pruebas unitarias")
class RecursoUseCaseTest {

    @Mock
    private RecursoGateway recursoGateway;
    @Mock
    private AlmacenamientoGateway almacenamientoGateway;
    @Mock
    private MultipartFile archivo;

    @InjectMocks
    private RecursoUseCase recursoUseCase;

    private Recurso recursoBase;

    @BeforeEach
    void setUp() {
        recursoBase = new Recurso(1L, "Java Avanzado", "Desc", "Programación", "11",
                "PDF", "java.pdf", "/uploads/java.pdf", 1024L, 1L, "prof@test.com",
                LocalDateTime.now(), true);
    }

    // ---- publicarRecurso ----

    @Test
    @DisplayName("publicarRecurso: guarda recurso con valores por defecto")
    void publicarRecurso_datosValidos_guardaCorrectamente() {
        Recurso nuevo = new Recurso();
        nuevo.setTitulo("Matemáticas");
        nuevo.setArea("Ciencias");

        when(archivo.isEmpty()).thenReturn(false);
        when(archivo.getOriginalFilename()).thenReturn("mate.pdf");
        when(archivo.getSize()).thenReturn(512L);
        when(almacenamientoGateway.guardarArchivo(archivo, "Matemáticas")).thenReturn("/uploads/mate.pdf");
        when(recursoGateway.guardar(any())).thenReturn(recursoBase);

        Recurso resultado = recursoUseCase.publicarRecurso(nuevo, archivo);

        assertThat(nuevo.getTipo()).isEqualTo("PDF");
        assertThat(nuevo.getDisponible()).isTrue();
        assertThat(nuevo.getCreadoEn()).isNotNull();
        assertThat(nuevo.getNombreArchivo()).isEqualTo("mate.pdf");
        assertThat(nuevo.getTamanoBytes()).isEqualTo(512L);
        verify(almacenamientoGateway).guardarArchivo(archivo, "Matemáticas");
    }

    @Test
    @DisplayName("publicarRecurso: preserva tipo cuando se especifica")
    void publicarRecurso_conTipoEspecifico_preservaTipo() {
        Recurso nuevo = new Recurso();
        nuevo.setTitulo("Video Ciencias");
        nuevo.setArea("Ciencias");
        nuevo.setTipo("VIDEO");

        when(archivo.isEmpty()).thenReturn(false);
        when(archivo.getOriginalFilename()).thenReturn("ciencias.mp4");
        when(archivo.getSize()).thenReturn(2048L);
        when(almacenamientoGateway.guardarArchivo(any(), any())).thenReturn("/uploads/ciencias.mp4");
        when(recursoGateway.guardar(any())).thenReturn(recursoBase);

        recursoUseCase.publicarRecurso(nuevo, archivo);

        assertThat(nuevo.getTipo()).isEqualTo("VIDEO");
    }

    @Test
    @DisplayName("publicarRecurso: lanza excepción si título vacío")
    void publicarRecurso_tituloVacio_lanzaExcepcion() {
        Recurso nuevo = new Recurso();
        nuevo.setTitulo("");
        nuevo.setArea("Ciencias");

        assertThatThrownBy(() -> recursoUseCase.publicarRecurso(nuevo, archivo))
                .isInstanceOf(RuntimeException.class)
                .hasMessageContaining("título es obligatorio");
    }

    @Test
    @DisplayName("publicarRecurso: lanza excepción si área vacía")
    void publicarRecurso_areaVacia_lanzaExcepcion() {
        Recurso nuevo = new Recurso();
        nuevo.setTitulo("Libro");
        nuevo.setArea("");

        assertThatThrownBy(() -> recursoUseCase.publicarRecurso(nuevo, archivo))
                .isInstanceOf(RuntimeException.class)
                .hasMessageContaining("área es obligatoria");
    }

    @Test
    @DisplayName("publicarRecurso: lanza excepción si archivo null")
    void publicarRecurso_archivoNull_lanzaExcepcion() {
        Recurso nuevo = new Recurso();
        nuevo.setTitulo("Libro");
        nuevo.setArea("Arte");

        assertThatThrownBy(() -> recursoUseCase.publicarRecurso(nuevo, null))
                .isInstanceOf(RuntimeException.class)
                .hasMessageContaining("Debe adjuntar un archivo");
    }

    @Test
    @DisplayName("publicarRecurso: lanza excepción si archivo vacío")
    void publicarRecurso_archivoVacio_lanzaExcepcion() {
        Recurso nuevo = new Recurso();
        nuevo.setTitulo("Libro");
        nuevo.setArea("Arte");
        when(archivo.isEmpty()).thenReturn(true);

        assertThatThrownBy(() -> recursoUseCase.publicarRecurso(nuevo, archivo))
                .isInstanceOf(RuntimeException.class)
                .hasMessageContaining("Debe adjuntar un archivo");
    }

    // ---- obtenerPorId ----

    @Test
    @DisplayName("obtenerPorId: retorna recurso cuando existe")
    void obtenerPorId_existente_retornaRecurso() {
        when(recursoGateway.buscarPorId(1L)).thenReturn(recursoBase);
        assertThat(recursoUseCase.obtenerPorId(1L)).isEqualTo(recursoBase);
    }

    @Test
    @DisplayName("obtenerPorId: lanza excepción si no existe")
    void obtenerPorId_noExiste_lanzaExcepcion() {
        when(recursoGateway.buscarPorId(99L)).thenReturn(null);
        assertThatThrownBy(() -> recursoUseCase.obtenerPorId(99L))
                .isInstanceOf(RuntimeException.class)
                .hasMessageContaining("No existe recurso con id: 99");
    }

    // ---- buscarRecursos / listarTodos / listarPorUsuario ----

    @Test
    @DisplayName("buscarRecursos: delega en gateway")
    void buscarRecursos_retornaResultados() {
        when(recursoGateway.buscar("Ciencias", "10", "java")).thenReturn(List.of(recursoBase));
        assertThat(recursoUseCase.buscarRecursos("Ciencias", "10", "java")).hasSize(1);
    }

    @Test
    @DisplayName("listarTodos: retorna recursos disponibles")
    void listarTodos_retornaDisponibles() {
        when(recursoGateway.listarDisponibles()).thenReturn(List.of(recursoBase));
        assertThat(recursoUseCase.listarTodos()).hasSize(1);
    }

    @Test
    @DisplayName("listarPorUsuario: filtra por usuario")
    void listarPorUsuario_retornaDelUsuario() {
        when(recursoGateway.listarPorUsuario(1L)).thenReturn(List.of(recursoBase));
        assertThat(recursoUseCase.listarPorUsuario(1L)).hasSize(1);
    }

    // ---- descargarArchivo ----

    @Test
    @DisplayName("descargarArchivo: retorna bytes del archivo")
    void descargarArchivo_existente_retornaBytes() {
        byte[] contenido = new byte[]{1, 2, 3};
        when(recursoGateway.buscarPorId(1L)).thenReturn(recursoBase);
        when(almacenamientoGateway.obtenerArchivo("/uploads/java.pdf")).thenReturn(contenido);

        byte[] resultado = recursoUseCase.descargarArchivo(1L);
        assertThat(resultado).isEqualTo(contenido);
    }

    // ---- editarRecurso / eliminarRecurso ----

    @Test
    @DisplayName("editarRecurso: actualiza cuando existe")
    void editarRecurso_existente_actualiza() {
        when(recursoGateway.buscarPorId(1L)).thenReturn(recursoBase);
        when(recursoGateway.actualizar(eq(1L), any())).thenReturn(recursoBase);

        assertThat(recursoUseCase.editarRecurso(1L, recursoBase)).isNotNull();
    }

    @Test
    @DisplayName("editarRecurso: lanza excepción si no existe")
    void editarRecurso_noExiste_lanzaExcepcion() {
        when(recursoGateway.buscarPorId(99L)).thenReturn(null);
        assertThatThrownBy(() -> recursoUseCase.editarRecurso(99L, recursoBase))
                .isInstanceOf(RuntimeException.class)
                .hasMessageContaining("No existe recurso con id: 99");
    }

    @Test
    @DisplayName("eliminarRecurso: borra archivo y registro")
    void eliminarRecurso_existente_eliminaArchivoYRegistro() {
        when(recursoGateway.buscarPorId(1L)).thenReturn(recursoBase);

        recursoUseCase.eliminarRecurso(1L);

        verify(almacenamientoGateway).eliminarArchivo("/uploads/java.pdf");
        verify(recursoGateway).eliminar(1L);
    }

    @Test
    @DisplayName("eliminarRecurso: lanza excepción si no existe")
    void eliminarRecurso_noExiste_lanzaExcepcion() {
        when(recursoGateway.buscarPorId(99L)).thenReturn(null);
        assertThatThrownBy(() -> recursoUseCase.eliminarRecurso(99L))
                .isInstanceOf(RuntimeException.class)
                .hasMessageContaining("No existe recurso con id: 99");
    }
}

    // ── Tests adicionales para cobertura 90% ──

    @Test
    @DisplayName("publicarRecurso: lanza excepción si título es null")
    void publicar_tituloNull_lanzaExcepcion() {
        Recurso r = new Recurso(); r.setTitulo(null); r.setArea("Matemáticas");
        assertThatThrownBy(() -> recursoUseCase.publicarRecurso(r, mockArchivo))
                .isInstanceOf(RuntimeException.class).hasMessageContaining("título");
    }

    @Test
    @DisplayName("publicarRecurso: lanza excepción si área vacía")
    void publicar_areaVacia_lanzaExcepcion() {
        Recurso r = new Recurso(); r.setTitulo("Álgebra"); r.setArea("");
        assertThatThrownBy(() -> recursoUseCase.publicarRecurso(r, mockArchivo))
                .isInstanceOf(RuntimeException.class).hasMessageContaining("área");
    }

    @Test
    @DisplayName("publicarRecurso: lanza excepción si archivo es null")
    void publicar_archivoNull_lanzaExcepcion() {
        Recurso r = new Recurso(); r.setTitulo("Álgebra"); r.setArea("Matemáticas");
        assertThatThrownBy(() -> recursoUseCase.publicarRecurso(r, null))
                .isInstanceOf(RuntimeException.class).hasMessageContaining("archivo");
    }

    @Test
    @DisplayName("publicarRecurso: asigna tipo PDF si es null")
    void publicar_tipoNull_asignaPDF() {
        when(mockArchivo.isEmpty()).thenReturn(false);
        when(mockArchivo.getOriginalFilename()).thenReturn("doc.pdf");
        when(mockArchivo.getSize()).thenReturn(1024L);
        when(almacenamientoGateway.guardarArchivo(any(), anyString())).thenReturn("/ruta/doc.pdf");
        when(recursoGateway.guardar(any())).thenReturn(recursoBase);

        Recurso r = new Recurso(); r.setTitulo("Álgebra"); r.setArea("Matemáticas"); r.setTipo(null);
        recursoUseCase.publicarRecurso(r, mockArchivo);
        assertThat(r.getTipo()).isEqualTo("PDF");
    }

    @Test
    @DisplayName("buscarRecursos: delega en gateway con parámetros")
    void buscar_delegaEnGateway() {
        when(recursoGateway.buscar("Ciencias", "10", "biología")).thenReturn(List.of(recursoBase));
        assertThat(recursoUseCase.buscarRecursos("Ciencias", "10", "biología")).hasSize(1);
    }

    @Test
    @DisplayName("listarPorUsuario: delega en gateway")
    void listarPorUsuario_delegaEnGateway() {
        when(recursoGateway.listarPorUsuario(1L)).thenReturn(List.of(recursoBase));
        assertThat(recursoUseCase.listarPorUsuario(1L)).hasSize(1);
    }

    @Test
    @DisplayName("descargarArchivo: retorna bytes del archivo")
    void descargar_retornaBytes() {
        when(recursoGateway.buscarPorId(1L)).thenReturn(recursoBase);
        when(almacenamientoGateway.obtenerArchivo(anyString())).thenReturn(new byte[]{1, 2, 3});
        byte[] bytes = recursoUseCase.descargarArchivo(1L);
        assertThat(bytes).hasSize(3);
    }

    @Test
    @DisplayName("editarRecurso: lanza excepción si no existe")
    void editar_noExiste_lanzaExcepcion() {
        when(recursoGateway.buscarPorId(99L)).thenReturn(null);
        assertThatThrownBy(() -> recursoUseCase.editarRecurso(99L, recursoBase))
                .isInstanceOf(RuntimeException.class).hasMessageContaining("99");
    }
}
